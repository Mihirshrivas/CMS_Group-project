--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-4.pgdg90+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-4.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: add_med; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.add_med (
    med_name character varying(100) NOT NULL,
    comp_name character varying(70) NOT NULL,
    quntity character varying(70) NOT NULL,
    dom character varying(50) NOT NULL,
    doe character varying(50) NOT NULL,
    mrp character varying(50) NOT NULL
);


--
-- Name: admin_login; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_login (
    admin_id integer NOT NULL,
    password character varying(100) NOT NULL
);


--
-- Name: admin_login_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_login_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_login_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_login_admin_id_seq OWNED BY public.admin_login.admin_id;


--
-- Name: appointment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment (
    app_id integer NOT NULL,
    doctorname character varying(80) NOT NULL,
    timing character varying(80) NOT NULL,
    date character varying(80) NOT NULL,
    patientname character varying(80) NOT NULL,
    username character varying(80)
);


--
-- Name: appointment_app_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.appointment_app_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: appointment_app_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.appointment_app_id_seq OWNED BY public.appointment.app_id;


--
-- Name: doctor_reg; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doctor_reg (
    doc_id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    contact character varying(100) NOT NULL,
    address character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    qualifications character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    gender character varying(50),
    spl character varying(100),
    question character varying(300),
    answer character varying(100)
);


--
-- Name: doctor_reg_doc_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.doctor_reg_doc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: doctor_reg_doc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.doctor_reg_doc_id_seq OWNED BY public.doctor_reg.doc_id;


--
-- Name: pat_reg; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pat_reg (
    pat_id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    contact character varying(100) NOT NULL,
    address character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    adhar_no character varying(100) NOT NULL,
    dob character varying(80) NOT NULL,
    gender character varying(50),
    password character varying(100) NOT NULL,
    bloodgroup character varying(25),
    question character varying(300),
    answer character varying(100)
);


--
-- Name: pat_reg_pat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pat_reg_pat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pat_reg_pat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pat_reg_pat_id_seq OWNED BY public.pat_reg.pat_id;


--
-- Name: pharm_login; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pharm_login (
    phar_id integer NOT NULL,
    password character varying(100) NOT NULL
);


--
-- Name: pharm_login_phar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pharm_login_phar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pharm_login_phar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pharm_login_phar_id_seq OWNED BY public.pharm_login.phar_id;


--
-- Name: prescription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prescription (
    pat_username character varying(100) NOT NULL,
    date character varying(100),
    med_name character varying(80),
    "time" character varying(80),
    quantity character varying(80)
);


--
-- Name: rec_reg; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rec_reg (
    rec_id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    contact character varying(100) NOT NULL,
    address character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    qualifications character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    gender character varying(50),
    question character varying(300),
    answer character varying(100)
);


--
-- Name: rec_reg_rec_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rec_reg_rec_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rec_reg_rec_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rec_reg_rec_id_seq OWNED BY public.rec_reg.rec_id;


--
-- Name: admin_login admin_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_login ALTER COLUMN admin_id SET DEFAULT nextval('public.admin_login_admin_id_seq'::regclass);


--
-- Name: appointment app_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment ALTER COLUMN app_id SET DEFAULT nextval('public.appointment_app_id_seq'::regclass);


--
-- Name: doctor_reg doc_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doctor_reg ALTER COLUMN doc_id SET DEFAULT nextval('public.doctor_reg_doc_id_seq'::regclass);


--
-- Name: pat_reg pat_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pat_reg ALTER COLUMN pat_id SET DEFAULT nextval('public.pat_reg_pat_id_seq'::regclass);


--
-- Name: pharm_login phar_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pharm_login ALTER COLUMN phar_id SET DEFAULT nextval('public.pharm_login_phar_id_seq'::regclass);


--
-- Name: rec_reg rec_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rec_reg ALTER COLUMN rec_id SET DEFAULT nextval('public.rec_reg_rec_id_seq'::regclass);


--
-- Data for Name: add_med; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.add_med (med_name, comp_name, quntity, dom, doe, mrp) FROM stdin;
Amanat	Sun Pharamceuticals	1000	23//11/2021	23//11/2023	22
 Etamsylate	 Astra Zeneca	 500	 23//10/2021	 23//10/2022	 110
 Ecosprin	 Cipla	 435	 23//08/2021	 23//08/2022	 20
 Doxil	 Pfizer	 600	 28//9/2021	  28//9/2022	 1202
Glycomate	USV Limited	100	 10/09/2021	10/09/2022	43
 Hifenac PTab	 Intas Pharmaceuticals	 300	 6/09/2021	 6/09/2022	 83
 Istamat	 Sun Pharmaceuticals	300 	 23/10/2021	  23/10/2022	 405
 Lanzol Syrup	 Cipla	200	30/10/2021	 30/10/2022	 147
Kenacort	 Abbot	 450	 03/11/2021	 03/11/2022	 82
 Meloxicam	 Zydus Cadila Ltd	 300	10/11//2021	 10/11/2023	 250
 Nevirapind	 Cipla	 200	25/10/2021	 25/10/2023	 140
Oxycodone	Percocet	350 	13/10/2021 	 13/10/2023	 160
Prednisone	Ranbaxi	100 	17/10/2021 	17/10/2023	90
Ritonavir	Senova Ltd	250 	18/10/2021	18/10/2023 	20 
Santura	Trospium 	350 	14/11/2021 	14/11/2023 	600 
Tamiflu 	Pentazocine 	500 	17/11/2021 	17/11/2024 	100
Unithroid 	Levothyroxy Ltd 	50 	18/11/2021 	18/11/2024 	42 
Vicks	Procter & Gamble Hygiene and Health Care Limited (P&GHHCL) 	350 	8/10/2021 	8/04/2022 	20
 Amrutanjan	Amrutanjan Healthcare 	200 	17/11/2021	17/11/2021 	500 
\.


--
-- Data for Name: admin_login; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_login (admin_id, password) FROM stdin;
1	123456
\.


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment (app_id, doctorname, timing, date, patientname, username) FROM stdin;
10	Atharv Sathe	10.00 - 10.15	27-11-2021	Ambadas Malegave	ambadas11
11	Mihir Shrivas	11.00 - 11.15	27-11-2021	Ambadas Malegave	ambadas11
12	Atharv Sathe	11.00 - 11.15	27-11-2021	Rahul Yadav	rahul13
13	Atharv Sathe	11.30 - 11.45	27-11-2021	Om Chavan	om2
14	Atharv Sathe	6.00 - 6.15	27-11-2021	Bhushan Patil	bhushan24
15	Atharv Sathe	7.00 - 7.15	27-11-2021	Samarth Napte	samarth06
16	Atharv Sathe	8.00 - 8.15	27-11-2021	Rishikesh Kumbhar	rishi12
17	Atharv Sathe	8.45 - 9.00	27-11-2021	Prathamesh Shelke	pshelke8
20	Mihir Shrivas	10.00 - 10.15	27-11-2021	Ambadas Malegave	ambadas11
21	Harsh Yadavade	10.00 - 10.15	29-11-2021	Ambadas Malegave	ambadas11
22	Atharv Sathe	10.00 - 10.15	29-11-2021	Ambadas Malegave	ambadas11
23	Atharv Sathe	10.30 - 10.45	29-11-2021	Rahul Yadav	rahul13
24	Atharv Sathe	11.15 - 11.30	29-11-2021	Om Chavan	om2
25	Atharv Sathe	6.00 - 6.15	29-11-2021	Bhushan Patil	bhushan24
26	Jayesh Singh	6.00 - 6.15	29-11-2021	Ambadas Malegave	ambadas11
27	Jayesh Singh	11.45 - 12.00	29-11-2021	Ambadas Malegave	ambadas11
29	Jayesh Singh	10.00 - 10.15	02-12-2021	Ambadas Malegave	ambadas11
30	Atharv Sathe	10.00 - 10.15	01-12-2021	Om Chavan	om2
32	Atharv Sathe	11.30 - 11.45	30-11-2021	Ambadas Malegave	ambadas11
33	Atharv Sathe	10.30 - 10.45	01-12-2021	Ambadas Malegave	ambadas11
35	Atharv Sathe	11.30 - 11.45	04-12-2021	Rishikesh Kumbhar	rishi12
39	Atharv Sathe	8.00 - 8.15	01-12-2021	Ambadas Malegave	ambadas11
40	Jayesh Singh	11.15 - 11.30	02-12-2021	Om Chavan	om2
\.


--
-- Data for Name: doctor_reg; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doctor_reg (doc_id, name, email, contact, address, username, qualifications, password, gender, spl, question, answer) FROM stdin;
9	Mihir Shrivas	mihirshrivas22@gmail.com	9702309548	Titwala ,Maharashtra ,India	mihir22	MD	1234	Male	Surgeon and Family Physician	\N	\N
10	Jayesh Singh	jayeshrasingh123@gmail.com	9021100192	Badlapur , Maharashtra ,India	jayesh05	MBBS	1234	Male	Orthopedic	\N	\N
11	Harsh Yadavade	harshyadavade68@gmail.com	7028791659	Badlapur ,Maharashtra ,India	harsh45	BAMS	1234	Male	Family Physician	\N	\N
8	Atharv Sathe	atharvsathe0302@gmail.com	9764421566	Ratnagiri , Maharashtra ,India	atharv03	MBBS	1234	Male	Heart Specialist	In what city were you born?	Ratnagiri
\.


--
-- Data for Name: pat_reg; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pat_reg (pat_id, name, email, contact, address, username, adhar_no, dob, gender, password, bloodgroup, question, answer) FROM stdin;
12	Rahul Yadav	rahulyadav13@gmail.com	7400280838	Thane ,Maharashtra ,India	rahul13	7554 3112 9765	21-02-1992	Male	1234	A -ve	\N	\N
14	Bhushan Patil	bhushan24@gmail.com	7710930229	Mumbai , Maharashtra ,India	bhushan24	5783 2711 6542	29-04-1996	Male	1234	B-ve	\N	\N
15	Samarth Napte	samarthnapte06@gmail.com	9284480845	Badlapur , Maharashtra ,India	samarth06	5854 6135 5895	10-05-1998	Male	1234	O +ve	\N	\N
16	Rishikesh Kumbhar	rishik12@gmail.com	7709045737	Ambernath ,Maharashtra ,India	rishi12	6789 4564 1331	25-06-2000	Male	1234	O -ve	\N	\N
17	Prathamesh Shelke	pshelke8@gmail.com	9136085152	Virar ,Maharashtra ,India	pshelke8	7754 6543 2589	18-07-2002	Male	1234	AB +ve	\N	\N
18	Durwankur Bhute	dmbhute@gmail.com	7588559841	Nhava , JNPT , Maharashtra ,India	durwa1	8855 6543 7916	15-08-2004	Male	1234	AB -ve	\N	\N
13	Om Chavan	omchavan2@gmail.com	8108775021	Kalyan , Maharashtra ,India	om2	4554 7915 6742	09-03-1994	Male	1234	B +ve	In what city were you born?	Mumbai
11	Ambadas Malegave	ambadas11	9136554957	Thane ,Maharashtra ,India	ambadas11	9476 5882 4332	01-01-1990	Male	1234	A +ve	In what city were you born?	Mumbai
\.


--
-- Data for Name: pharm_login; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pharm_login (phar_id, password) FROM stdin;
1	1234
\.


--
-- Data for Name: prescription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prescription (pat_username, date, med_name, "time", quantity) FROM stdin;
ambadas11	25-11-2021	Acacia	BREAKFAST (B)	1 at a TIME
ambadas11	25-11-2021	 Istamat	BREAKFAST (A)	1 at a TIME
ambadas11	27-11-2021	Acacia	LUNCH (B)	1 at a TIME
ambadas11	27-11-2021	Fabi	DINNER (A)	1 at a TIME
ambadas11	27-11-2021	Acacia	BREAKFAST (B) , LUNCH (A) , DINNER (B)	1 at a TIME
ambadas11	27-11-2021	Fabiflu	BREAKFAST (B) , LUNCH (A) , DINNER (B)	1 at a TIME
ambadas11	30-11-2021	 Ecosprin	LUNCH (B)	1 at a TIME
ambadas11	30-11-2021	Glycomate	LUNCH (A)	1 at a TIME
ambadas11	30-11-2021	 Hifenac PTab	LUNCH (A)	1 at a TIME
ambadas11	30-11-2021	 Doxil	BREAKFAST (A)  , DINNER (A)	1 at a TIME
ambadas11	30-11-2021	 Meloxicam	BREAKFAST (A) , LUNCH (B) , DINNER (A)	1 at a TIME
ambadas11	30-11-2021	Fabiflu	BREAKFAST (A) , LUNCH (B) , DINNER (A)	1 at a TIME
ambadas11	01-12-2021	Oxycodone	BREAKFAST (A) , LUNCH (B) , DINNER (A)	1 at a TIME
ambadas11	01-12-2021	Fabiflu	BREAKFAST (A) , LUNCH (B) , DINNER (A)	1 at a TIME
\.


--
-- Data for Name: rec_reg; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rec_reg (rec_id, name, email, contact, address, username, qualifications, password, gender, question, answer) FROM stdin;
3	Ritvik Shetty	rshetty@gmail.com	9004846749	Mira Bhayandar ,Maharashtra ,India	ritvik7	HSC	1234	Male 	\N	\N
2	Sahil Shetty	sshetty@gmail.com	7676991728	Kalwa ,Maharashtra, India	sahil66	HSC	1234	Male 	What high school did you attend?	New
\.


--
-- Name: admin_login_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_login_admin_id_seq', 1, false);


--
-- Name: appointment_app_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.appointment_app_id_seq', 40, true);


--
-- Name: doctor_reg_doc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doctor_reg_doc_id_seq', 19, true);


--
-- Name: pat_reg_pat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pat_reg_pat_id_seq', 22, true);


--
-- Name: pharm_login_phar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pharm_login_phar_id_seq', 1, false);


--
-- Name: rec_reg_rec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rec_reg_rec_id_seq', 8, true);


--
-- Name: admin_login admin_login_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_login
    ADD CONSTRAINT admin_login_pkey PRIMARY KEY (admin_id);


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (app_id);


--
-- Name: doctor_reg doctor_reg_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doctor_reg
    ADD CONSTRAINT doctor_reg_pkey PRIMARY KEY (doc_id);


--
-- Name: doctor_reg doctor_reg_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doctor_reg
    ADD CONSTRAINT doctor_reg_username_key UNIQUE (username);


--
-- Name: pat_reg pat_reg_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pat_reg
    ADD CONSTRAINT pat_reg_pkey PRIMARY KEY (pat_id);


--
-- Name: pat_reg pat_reg_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pat_reg
    ADD CONSTRAINT pat_reg_username_key UNIQUE (username);


--
-- Name: pharm_login pharm_login_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pharm_login
    ADD CONSTRAINT pharm_login_pkey PRIMARY KEY (phar_id);


--
-- Name: rec_reg rec_reg_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rec_reg
    ADD CONSTRAINT rec_reg_pkey PRIMARY KEY (rec_id);


--
-- Name: rec_reg rec_reg_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rec_reg
    ADD CONSTRAINT rec_reg_username_key UNIQUE (username);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO amjh_3frb_user;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES  TO amjh_3frb_user;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES  TO amjh_3frb_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS  TO amjh_3frb_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO amjh_3frb_user;


--
-- PostgreSQL database dump complete
--

